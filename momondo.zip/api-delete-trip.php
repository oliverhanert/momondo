<?php
// Validate the trip id
// 1, 2, 3, 4
if( ! isset($_POST['trip_id']) ){
  http_response_code(400);
  // echo 'trip_id missing';
  echo json_encode(['info'=>'trip_id missing']);
  exit();
}

if( ! ctype_digit($_POST['trip_id']) ){
  http_response_code(400);
  // echo 'trip_id must be a digit';
  echo json_encode(['info'=>'trip_id must be a digit']);
  exit();  
}

// TODO: Delete the trip from the database
try{
  $db = new PDO('sqlite:'.__DIR__.'/momondo2.db');
  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $q = $db->prepare('DELETE FROM trips WHERE id = :id');
  $q->bindValue(':id', $_POST['trip_id']);
  $q->execute();
  // Success
  // echo "trip_id {$_POST['trip_id']}";
  echo json_encode(['info'=>'trip deleted', 'trip_id'=>$_POST['trip_id']]);
  exit();
}catch(Exception $ex){
  http_response_code(500);
  echo json_encode(['info'=>'System under maintainance']);
  exit();  
}