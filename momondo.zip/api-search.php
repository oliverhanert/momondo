<?php
ini_set('display_errors', 1);

try{
    $search_city_name = $_GET['search_city_name'] ?? 0;
    // Connect to the database
    $db = new PDO('sqlite:'.__DIR__.'/momondo.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $q = $db->prepare('SELECT * FROM flights WHERE city_name LIKE :search_city_name');
    $q->bindValue(':search_city_name', '%'.$search_city_name.'%');
    $q->execute();
    $flights = $q->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($flights);
}catch(Exception $ex){
    http_response_code(400);
    echo json_encode(['info'=>'upppss...']);
}