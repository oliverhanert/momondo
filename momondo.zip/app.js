// ################################ Viser "From" resultater ################################
function show_from_results() {
    const the_input = document.querySelector("#from-input");

    if ( the_input.value.length > 0 ) {
        document.querySelector("#from-results").style.display = "block";
        document.querySelector("#from-input").style.border = "1px solid #DABDF5";
        get_cities_from()
    } else {
        document.querySelector("#from-results").style.display = "none";
    }
}

async function get_cities_from() {
    const the_input = document.querySelector("#from-input").value;
    let conn = await fetch('api-search.php?search_city_name='+the_input)
    let data = await conn.json(); // [{"city_name" : "a"}, {"city_name" : "b"}, {"city_name" : "c"}]
    let div_city = `<div class="search_city_name" onclick="select_city_from()">
                        <img src="images/#img#" alt="">
                        <div class="city-info">
                            <div class="top">
                                <p class="city-title">#city#</p>
                                <p class="city-country">, #country# </p>
                                <p class="city-airport-short">, #airport_short#</p>
                            </div>
                            <div class="bottom">
                                <p class="city-airport">#airport#</p>
                            </div>
                        </div>
                    </div>`
    let all_cities = ""
    for ( let i = 0; i < data.length; i++ ) {
        let city = data[i]
        let city_name = city.city_name
        console.log(city_name)
        let copy_div_city = div_city // copy of div_city
        copy_div_city = copy_div_city.replace("#city#", city_name)
        copy_div_city = copy_div_city.replace("#country#", city.city_country)
        copy_div_city = copy_div_city.replace("#airport_short#", city.city_airport_abr)
        copy_div_city = copy_div_city.replace("#img#", city.city_image)
        copy_div_city = copy_div_city.replace("#airport#", city.city_airport)

        all_cities += copy_div_city

    }
    console.log(data)
    document.querySelector("#from-results").insertAdjacentHTML("afterbegin", all_cities)
}

// ################################ Vælg resultat og vis i input ################################

function select_city_from () {
    const city_name = event.target.querySelector(".city-title").innerText
    console.log(city_name);
    document.querySelector("#from-input").value = city_name
    document.querySelector("#from-results").style.display = "none"
    document.querySelector("#from-results").innerHTML = ""
}

function select_city_to () {
    const city_name = event.target.querySelector(".city-title").innerText
    console.log(city_name);
    document.querySelector("#to-input").value = city_name
    document.querySelector("#to-results").style.display = "none"
    document.querySelector("#to-results").innerHTML = ""
}

// ################################ Viser "To" resultater ################################
function show_to_results() {
    const the_input = document.querySelector("#to-input")

    if ( the_input.value.length > 0 ) {
        document.querySelector("#to-results").style.display = "block";
        document.querySelector("#to-input").style.border = "1px solid #DABDF5";
        get_cities_to()
    } else {
        document.querySelector("#to-results").style.display = "none";
    }
}

// function hide_to_results() {
//     document.querySelector("#to-results").style.display = "none";
//     document.querySelector("#to-input").style.border = "none";
// }

async function get_cities_to() {
    const the_input = document.querySelector("#to-input").value;
    let conn = await fetch('api-search.php?search_city_name='+the_input)
    let data = await conn.json() // [{"city_name" : "a"}, {"city_name" : "b"}, {"city_name" : "c"}]
    let div_city = `<div class="search_city_name" onclick="select_city_to()">
                        <img src="images/#img#" alt="">
                        <div class="city-info">
                            <div class="top">
                                <p class="city-title">#city#</p>
                                <p class="city-country">, #country# </p>
                                <p class="city-airport-short">, #airport_short#</p>
                            </div>
                            <div class="bottom">
                                <p class="city-airport">#airport#</p>
                            </div>
                        </div>
                    </div>`
    let all_cities = ""
    for ( let i = 0; i < data.length; i++ ) {
        let city = data[i]
        let city_name = city.city_name
        console.log(city_name)
        let copy_div_city = div_city // copy of div_city
        copy_div_city = copy_div_city.replace("#city#", city_name)
        copy_div_city = copy_div_city.replace("#country#", city.city_country)
        copy_div_city = copy_div_city.replace("#airport_short#", city.city_airport_abr)
        copy_div_city = copy_div_city.replace("#img#", city.city_image)
        copy_div_city = copy_div_city.replace("#airport#", city.city_airport)
        all_cities += copy_div_city

    }
    console.log(data)
    document.querySelector("#to-results").insertAdjacentHTML("afterbegin", all_cities)
}

// ################################ Menu toggle ################################


function toggle_menu(){
    const domMenu = document.getElementById('slide_in_menu');
    if(domMenu.classList.contains('active')){
        domMenu.classList.remove('active')
    }else{
        domMenu.classList.add('active')
    }
}

// ################################ Open pop up on admin page ################################


const popup = document.querySelector('.popup');
function showPopup() {
  popup.classList.add('open');
}
function hidePopup() {
  popup.classList.remove('open');
}

// ################################ Switch between tabs on admin page ################################


function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
    
    }
    
    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();
  
// ################################ Checks if email is available ################################

async function is_email_available() {
    console.log('x')
    const frm = document.querySelector("form")
    const conn = await fetch('api-is-email-available.php', {
        method : "POST",
        body : new FormData(frm)
    })
    if ( !conn.ok ) {
        document.querySelector(".info").style.display = "block"
    }
}

function reset_if_email_available() {
    console.log('reset')
    event.target.value = "";
    document.querySelector(".info").style.display = "none"
}

// ################################ Shows flights results ################################

async function show_selected_flight() {
    document.querySelector("#flights").style.display = "none";
    // Clean the flights div, so we only show fresh results
    document.querySelector('#flights').innerHTML = ""
    // Get the data from the input field
    const search_for = document.querySelector("#to-input").value
    let conn = await fetch('api-show-results.php?search_city_name='+search_for)
    const flights = await conn.json()
    console.log(flights)
    let all_flights = ""
    const original_flight_blueprint = `
        <div class="flight">
        <div class="left">
            <div class="left_container">
                <div class="from_container">
                    <div> 
                        <img class="airline_logo" src="images/#airline_logo#" alt="flight company">
                    </div>
                    <div class="departure_info"> 
                        <p class="top">#departure_time# - #departure_landing_time#</p>
                        <p class="bottom">#departure_airport# - #arrival_airport#</p>
                    </div>
                </div>
                <div class="to_container mt05">
                    <div> 
                        <img class="airline_logo_2" src="images/#airline_logo_2#" alt="flight company">
                    </div>
                    <div class="departure_info_2"> 
                        <p class="top">#departure_time_2# - #departure_landing_time_2#</p>
                        <p class="bottom">#departure_airport_2# - #arrival_airport_2#</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="right">
            <div class="price_container"> 
                <p>#flight_price#</p>
                <button class="show-offer">Se tilbud</button>
            </div>
            </div>
        </div>
        </div>`
    flights.forEach( flight => {
        console.log(flight)
        let div_flight = original_flight_blueprint
        div_flight = div_flight.replace('#airline_logo#', flight.airline_logo)
        div_flight = div_flight.replace('#departure_airport#', flight.departure_airport)
        div_flight = div_flight.replace('#departure_time#', flight.departure_time)
        div_flight = div_flight.replace('#arrival_airport#', flight.arrival_airport)
        div_flight = div_flight.replace('#departure_landing_time#', flight.departure_landing_time)
        div_flight = div_flight.replace('#airline_logo_2#', flight.airline_logo)
        div_flight = div_flight.replace('#departure_airport_2#', flight.departure_airport)
        div_flight = div_flight.replace('#departure_time_2#', flight.return_time)
        div_flight = div_flight.replace('#arrival_airport_2#', flight.arrival_airport)
        div_flight = div_flight.replace('#departure_landing_time_2#', flight.return_landing_time)
        div_flight = div_flight.replace('#flight_price#', flight.flight_price)
        all_flights += div_flight
    } )
    // location.href = 'view-flight-results.php?search_city_name=' + search_for;

    document.querySelector("#flights").insertAdjacentHTML('afterbegin', all_flights);
    document.querySelector("#main").style.display = "none";
    document.querySelector("#flights").style.display = "block";
    
    
}

// ################################ Shows flights results ################################

async function delete_trip(){
    const frm = event.target.form
    console.log(frm)
    const conn = await fetch('api-delete-trip.php', {
      method : "POST",
      body : new FormData(frm)
    })
    const data = await conn.json()
    if( ! conn.ok ){
      // Sweet alert: ups... fligth not found
      console.log(data)
      return
    }
    // Success
    console.log(data)
    frm.remove()
  }

  function changeColor(image) {
    if (image.src.indexOf("circleRed.png")>-1) {
        image.src = "circleBlue.png"; 
    } else {
        image.src = "circleRed.png";
    }
}
