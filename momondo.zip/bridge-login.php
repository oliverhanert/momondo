<?php

$correct_email = 'a@a.com';
$correct_password = 'password';


if( ! filter_var( $_POST['email'], FILTER_VALIDATE_EMAIL ) ){
    header('Location: login');
    exit();
} 
// Check if the user's email matches the correct email
if ( $_POST['email'] != $correct_email ) {
    header('Location: login');
    exit();
}


// Check if the user's email matches the correct email
if($correct_password != $_POST['password']){
    header('Location: login');
    exit();
} 

// Success
session_start();
$_SESSION['user_name'] = 'Thomas';
$_SESSION['email'] = 'thomashansen@gmail.com';
header("Location: admin");


?>