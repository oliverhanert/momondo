<footer>
  <div class="top-footer">
    <div class="col">
      <p class="footer-header">Firma</p>
      <a href="">Om</a>
      <a href="">Jobmuligheder</a>
      <a href="">Mobil</a>
      <a href="">Discover</a>
      <a href="">Sådan fungerer vi</a>
      <a href="">Derfor vælger rejsende Momondo</a>
      <a href="">Bæredygtighed</a>
      <a href="">Momondo-kuponkoder</a>
    </div>
    <div class="col">
    <p class="footer-header">Kontakt os</p>
      <a href="">Hjælp/FAQ</a>
      <a href="">Presse</a>
      <a href="">Affiliates</a>
      <a href="">Annoncér hos os</a>
    </div>
    <div class="col">
    <p class="footer-header">Mere</p>
      <a href="">Flyselskabsgebyrer</a>
      <a href="">Flyselskaber</a>
    </div>
  </div>
  <div class="bottom-footer">
    <a href="">Privatlivspolitik</a>
    <a href="">Vilkår & betingelser</a>
    <a href="">Aftryk</a>
    <a href="">@2022 momondo</a>
  </div>
</footer>

<script src="validator.js"></script>

<script>
  async function signup(){
    const the_form = document.querySelector("#signup_form")
    console.log(the_form)
    const conn = await fetch('api-signup.php', {
      method : "POST",
      body : new FormData(the_form)
    })
    if( ! conn.ok ){
      Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong!',
          footer: '<a href="">Why do I have this issue?</a>'
})
      
      console.log("uppssss....");
      
      return
    }
    const data = await conn.json() // convert text to JSON
    // Success
    // window.location='login'
    console.log(data.message)
    Swal.fire(
      'Velkommen ' + data.message,
      'Din profil er nu oprettet',
      'success').then(function() {
    window.location = "login";
});


}

  
   

</script>

<script src="app.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>