<?php
$language_allowed = ['en', 'dk'];
$language = $_GET['language'] ?? 'dk';

if( ! in_array($language, $language_allowed) ) {
    $language = 'dk';
}

$dictionary=[
    // Front page
    'dk_velkommen' => 'Find og sammenlign billige flybilletter online',
    'en_velkommen' => 'Find and compare cheap flights',

    'dk_fra' => 'Fra',
    'en_fra' => 'From',
    'dk_til' => 'Til',
    'en_til' => 'To',
    'dk_søg' => 'Søg',
    'en_søg' => 'Search',

    'dk_featured1' => 'Fantastiske september-steder',
    'en_featured1' => 'Great september-destinations',
    'dk_featured2' => 'September er en vidunderlig tid at tage en improviseret tur med stadig godt vejr, men færre turister og lavere priser.',
    'en_featured2' => 'September is a great time to take a spontaneous trip with great weather, but less tourists and lower prices.',
    'dk_læs' => 'Læs artiklen',
    'en_læs' => 'Read article',

    'dk_option' => 'Derfor vælger rejsende momondo',
    'en_option' => 'Here is why travellers choose Momondo',
    'dk_option1' => 'De bedste rejsetilbud',
    'en_option1' => 'The best travel prices',
    'dk_option1_2' => 'Find de bedste tilbud på mere end 900 forskellige rejsesites',
    'en_option1_2' => 'Find the best offers on 900+ different destinations',
    'dk_option2' => 'Bestil med fleksibilitet',
    'en_option2' => 'Offer with flexibility',
    'dk_option2_2' => 'Find fly nemt uden ændringsgebyrer',
    'en_option2_2' => 'Find the best flights without extra charges',
    'dk_option3' => 'Rejs med mindre CO₂',
    'en_option3' => 'Travel with less CO₂',
    'dk_option3_2' => 'Se rejsemulighedernes miljømæssige påvirkning',
    'en_option3_2' => 'See how each travel destination affects the environment',
    'dk_option4' => 'Anbefales af eksperter',
    'en_option4' => 'Recommended by experts',
    'dk_option4_2' => 'Momondo-appen er Editors Choice i App Store',
    'en_option4_2' => 'The Momondo-app is Editors Choice in App Store',

    'dk_populærebyer' => 'Populære byer',
    'en_populærebyer' => 'Trending cities',
    'dk_populærebyer2' => 'De mest søgte byer på Momondo',
    'en_populærebyer2' => 'The most searched for destinations on Momondo',

    'dk_populærelande' => 'Populære lande',
    'en_populærelande' => 'Trending countries',
    'dk_populærelande2' => 'De mest søgte lande på Momondo',
    'en_populærelande2' => 'The most searched for countries on Momondo',
    'dk_flytil' => 'Fly til',
    'en_flytil' => 'Flights to',

    // Admin
    'dk_hej' => 'Hej',
    'en_hej' => 'Hi',

    // Navigation
    'dk_fly' => 'Fly',
    'en_fly' => 'Flights',
    'dk_logind' => 'Log ind',
    'en_logind' => 'Login',
    'dk_overnatning' => 'Overnatning',
    'en_overnatning' => 'Stays',
    'dk_bil' => 'Bil',
    'en_bil' => 'Car hire',
    'dk_færger' => 'Færger',
    'en_færger' => 'Ferries',
    'dk_nyhed' => 'NYHED',
    'en_nyhed' => 'NEW',
    'dk_oplevelser' => 'Oplevelser',
    'en_oplevelser' => 'Things to do',
    'dk_pakkerejser' => 'Pakkerejser',
    'en_pakkerejser' => 'Travel packages',
    'dk_restriktioner' => 'Rejserestriktioner',
    'en_restriktioner' => 'Travel restrictions',

    // Trips page
    'dk_trips1' => 'Dine gemte rejser',
    'en_trips1' => 'Your saved destinations',
    'dk_trips2' => 'Herunder kan du se alt lige fra dine kommende rejser til rejser du har markeret som favorit.',
    'en_trips2' => 'This is your upcoming destinations and places your marked as your favorites',
    'dk_afrejsedato' => 'Afrejsedato',
    'en_afrejsedato' => 'Departure date',

    // Other
    'dk_opret' => 'Opret',
    'en_opret' => 'Create'
]
?>