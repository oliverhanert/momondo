<?php
session_start();
if( ! $_SESSION) {
    header('Location: login');
    exit();
}
$_title = 'Velkommen, '.$_SESSION['user_name'];
$_page = 'profil';
require_once __DIR__.'/comp_header.php';
?>

    <main id="admin-main">

        <div class="top-section">
            <img id="profile_image_change_pop_up" src="images/profile-pic.png" alt="custom profile image" onclick="showPopup()">
            <h1> <?php echo $dictionary[$language."_hej"].' '.$_SESSION[user_name] ?> </h1>
            <div class="user_info">
                <div>
                    <p>E-mail</p>
                    <p><?=$_SESSION['email']?></p>
                </div>
                <div class="mt1">
                    <p>Hjemmelufthavn</p>
                    <p>København, Danmark - Kastrup</p>
                </div>
            </div>
        </div>

        <div class="tab-container">
            <div class="tab">
                <button class="tablinks" onclick="openTab(event, 'Oversigt')" id="defaultOpen">Oversigt</button>
                <button class="tablinks" onclick="openTab(event, 'Indstillinger')">Indstillinger</button>
                <button class="tablinks" onclick="openTab(event, 'Kontoindstillinger')">Kontoindstillinger</button>
                <button class="tablinks" onclick="openTab(event, 'Rejsende')">Rejsende</button>
                <button class="tablinks" onclick="openTab(event, 'Betalingsoplysninger')">Betalingsoplysninger</button>
                <button class="tablinks" onclick="openTab(event, 'Notifikationer')">Notifikationer</button>

            </div>

            <div id="Oversigt" class="tabcontent">
                <h3>Oversigt</h3>
                <p>Dine tidligere søgninger</p>
            </div>

            <div id="Indstillinger" class="tabcontent">
                <h3>Indstillinger</h3>
                <p>Her kan du indstille din konto</p> 
            </div>

            <div id="Kontoindstillinger" class="tabcontent">
                <h3>Præferencer</h3>
                <p>....</p>
            </div>

            <div id="Rejsende" class="tabcontent">
                <h3>Rejsende</h3>
                <p>....</p>
            </div>

            <div id="Betalingsoplysninger" class="tabcontent">
                <h3>Betalingsoplysninger</h3>
                <p>....</p>
            </div>

            <div id="Notifikationer" class="tabcontent">
                <h3>Notifikationer</h3>
                <p>....</p>
            </div>
        </div>
        
        
        <div class="popup">
            <div class="blocker" onclick="hidePopup()"></div>
            <div class="contents">
            <div class="top-pop-up">
                <h3>Rediger dit profilbillede</h3>
                <!-- <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"> 
                    <path d="M5.72 5.72a.75.75 0 011.06 0L12 10.94l5.22-5.22a.75.75 0 111.06 1.06L13.06 12l5.22 5.22a.75.75 0 11-1.06 1.06L12 13.06l-5.22 5.22a.75.75 0 01-1.06-1.06L10.94 12 5.72 6.78a.75.75 0 010-1.06z"> </path>
                </svg> -->
        </div>
    
        <div class="upload-image-container mt1">
            <form action="admin" method="post" enctype="multipart/form-data">
                <input type="file" name="fileToUpload" id="fileToUpload">
                <input class="upload-btn" type="submit" value="Upload fra computer" name="submit">
                <p>Kun JPEG, PNG og GIF</p>
            </form>
        </div>   
            </div>
        </div>           
    </main>
    
<?php

$target_dir = 'images/';
$target_file = $target_dir . basename($_FILES['fileToUpload']['name']); // name of the file
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); // file-type : PNG / JPG / ZIP
$random_image_name = bin2hex(random_bytes(5)); // f1c845e507
$random_image_name = $random_image_name.'.'.$imageFileType; // f1c845e507.jpg
$tmp_name = $_FILES['fileToUpload']['tmp_name']; // The path : /Applications/XAMPP/xamppfiles/temp/phpSbonoj
move_uploaded_file($_FILES['fileToUpload']['tmp_name'], "images/$random_image_name");

require_once __DIR__.'/comp_footer.php';
?>