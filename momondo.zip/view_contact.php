<?php
$_title = 'Contact';
$_page = 'contact';
require_once __DIR__.'/comp_header.php';
?>

    <main>
      Contact
    </main>
    
<?php
require_once __DIR__.'/comp_footer.php';
?>