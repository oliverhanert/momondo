<?php

$_title = 'Login';
$_page = 'login';
require_once __DIR__.'/comp_header.php';
?>

    <main id="login-main">
        <div>
            <h1><?= $dictionary[$language.'_logind']?>, eller opret konto</h1>
            <p>Følg priser, organiser rejseplaner, og få adgang til medlemstilbud med din momondo-konto.</p>
        </div>
        <div>
            <form id="login_form" action="bridge-login.php" method="POST" onsubmit="validate(login); return false">
                <input name="email" type="text" placeholder="Din email-adresse" data-validate="email">
                <p>E-mail: a@a.com</p>
                <input name="password" type="password" placeholder="Din adgangskode">   
                <p>Password: password</p>                   
                <div class="button-container">
                    <button><?= $dictionary[$language.'_logind']?></button>
                </div>
                <p> Har du ikke en profil? Opret dig <a class="signup-link" href="signup">her</a>.</p>
            </form>
        </div>
    </main>
    
<?php
require_once __DIR__.'/comp_footer.php';
?>