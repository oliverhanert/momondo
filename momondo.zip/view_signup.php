<?php
require_once __DIR__.'/_x.php';
$_title = 'Signup';
$_page = 'signup';
require_once __DIR__.'/comp_header.php';
?>
    <main id="signup-main">
    <div>
            <h1>Opret din konto</h1>
            <p>Følg priser, organiser rejseplaner, og få adgang til medlemstilbud med din momondo-konto.</p>
    </div>
        <form method="POST" id="signup_form" onsubmit="validate(signup); return false">
        <div>
            <div class="signup-container">
                <label for="">
                Navn (min <?= _USER_NAME_MIN_LEN ?> max <?= _USER_NAME_MAX_LEN ?> antal tegn)
                </label>
                <input type="text" placeholder="Navn"
                maxlength="<?= _USER_NAME_MAX_LEN ?>"
                name = "user_name"
                data-validate="str"
                data-min = "<?= _USER_NAME_MIN_LEN ?>"
                data-max = "<?= _USER_NAME_MAX_LEN ?>"
                >
            </div>

            <div class="signup-container">
                <label for="">
                Efternavn (min <?= _USER_LAST_NAME_MIN_LEN ?> max <?= _USER_LAST_NAME_MAX_LEN ?> antal tegn)
                </label>
                <input type="text" placeholder="Efternavn"
                maxlength="<?= _USER_LAST_NAME_MAX_LEN ?>"
                name = "user_last_name"
                data-validate="str"
                data-min = "<?= _USER_LAST_NAME_MIN_LEN ?>"
                data-max = "<?= _USER_LAST_NAME_MAX_LEN ?>"
                >
            </div>

            <div class="signup-container">
                <label for="">Indtast din email</label>
                <input type="text" placeholder="Email"
                name = "email"
                data-validate="email"
                onblur="is_email_available()"
                onfocus="reset_if_email_available()"
                >
                <p class="info" style="display: none">
                    Den indtastede email er allerede i brug
                </p>
                <button>Opret bruger</button>
            </div>

        </div>
        </form>
    </main>
<?php
require_once __DIR__.'/comp_footer.php';
?>

  

</body>
</html>