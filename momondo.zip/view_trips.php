<?php
session_start();
if( ! $_SESSION) {
    header('Location: login');
    exit();
}

try{
    $db = new PDO('sqlite:'.__DIR__.'/momondo2.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $q = $db->prepare('SELECT * FROM trips');
    $q->execute();
    $trips = $q->fetchAll(PDO::FETCH_ASSOC);
    // echo json_encode($flights);
  }catch(Exception $ex){
    echo "Sorry, something went terribly wrong";
    exit();
  }

$_title = 'Trips';
$_page = 'trips';
require_once __DIR__.'/comp_header.php';
?>

    <main id="trips">
      <div class="top-section">
        <span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"> 
                <path d="M144.416 168.114c-6.09-4.657-12.645-10.746-20.042-18.614C114.836 139.357 110 129.914 110 121.433c0-11.31 9.475-20.914 21.12-21.412c8.843-.379 15.087 4.25 18.88 8.432c3.794-4.183 10.025-8.815 18.881-8.432c11.644.498 21.119 10.102 21.119 21.412c0 8.481-4.836 17.925-14.373 28.067c-7.395 7.866-13.952 13.955-20.046 18.617a9.205 9.205 0 0 1-11.165-.003zm-12.869-58.102c-6.367.272-11.547 5.395-11.547 11.421c0 5.77 4.031 13.106 11.658 21.218c6.818 7.251 12.824 12.865 18.342 17.143c5.521-4.281 11.528-9.896 18.342-17.143C175.969 134.54 180 127.203 180 121.433c0-6.025-5.18-11.148-11.546-11.421c-9.02-.379-13.781 8.855-13.98 9.249c-1.878 3.714-7.158 3.636-8.959-.023c-2.52-4.986-7.894-9.485-13.968-9.226zM105 160H45c-8.271 0-15-6.729-15-15v-15h-5a5 5 0 1 1 0-10h5v-20h-5a5 5 0 0 1 0-10h5V70h-5a5 5 0 0 1 0-10h5V45c0-8.271 6.729-15 15-15h110c8.271 0 15 6.729 15 15v40a5 5 0 1 1-10 0V45c0-2.757-2.243-5-5-5H80v110h25c2.762 0 5 2.238 5 5s-2.238 5-5 5zm-65-30v15c0 2.757 2.243 5 5 5h25V40H45c-2.757 0-5 2.243-5 5v15h5a5 5 0 0 1 0 10h-5v20h5a5 5 0 0 1 0 10h-5v20h5a5 5 0 1 1 0 10h-5z"> </path>
            </svg>
            <h1 class="mt1"><?= $dictionary[$language.'_trips1']?></h1>
            <p class="mt1"><?= $dictionary[$language.'_trips2']?></p>
        </span>
      </div>

      <?php
    foreach($trips as $trip){
    ?>

    <form class="trips mt1">
      <div class="trip">
        <div>
            <img src="images/<?= $trip['city_image'] ?>" alt="the image">
        </div>
        
        <div style="display: block">
            <p>Destination:</p>
            <span>
                <?= $trip['to_city'] ?>
            </span>
        </div>

        <div style="display: block">
            <p><?= $dictionary[$language.'_afrejsedato']?>:</p>
            <span>
                <?= $trip['departure_date'] ?>
            </span>
        </div>
          
          <button type="button" onclick="delete_trip()">
            🗑️
          </button>
        </div>
      </form>

    <?php
    }
    ?>

    </main>
    
<?php
require_once __DIR__.'/comp_footer.php';
?>